<?php 
	session_start();
	if(isset($_SESSION['user'])){
		echo "ok fine";
	}
	else{
		header('location:login.php');
	}

 ?>
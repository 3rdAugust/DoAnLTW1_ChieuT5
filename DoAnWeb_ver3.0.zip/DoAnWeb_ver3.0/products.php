<?php
    require "app/products.php";
    $brand = $_GET['brand'];
    $products = new products();
    $per_page = 8;
    $total_rows = $products->countAllProducts($brand);
	if (isset($_GET['page']))
	{
		$page = $_GET['page'];
	}
	else
		{
			$page = 1;
		}
    $data = $products->readAllProducts($brand, $page, $per_page);
    //var_dump($data);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="public/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="public/css/style.css">
    <title>Homepage</title>
</head>
<body>

    <header>
    <nav class="navbar navbar-default" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Home</a>
            </div>
    
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Products</a>
                        <ul class="dropdown-menu">
                            <li><a href="products.php?brand=Apple">Apple</a></li>
                            <li><a href="products.php?brand=Samsung">Samsung</a></li>
                            <li><a href="products.php?brand=Xiaomi">Xiaomi</a></li>
                            <li><a href="products.php?brand=Oppo">Oppo</a></li>
                        </ul>
                    </li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>

                <ul class="nav navbar-nav navbar-right">
                    <li><a href="#">My Cart</a></li>
                    <li><a href="#">Login</a></li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </div>
    </nav>
        
    </header>
    <div class="container">
        <div>
            <h1 class="title"><?php echo $brand?></h1>
        </div>
        <div class="row">
            <?php 
                foreach($data as $row)
                {
            ?>
                <div class="col-md-3" align="center">
                    <img src="public/img/<?php echo $row['brand']."/".$row['img']?>" class="hinhSP">
                        <h4><?php echo $row['name']?></h4>
                            <b>Price:</b>
                            <div class = "price">
                            <?php echo $row['price']?>
                            </div>
                            <b>VND</b>
                        <div>
                            <a class="btn btn-primary" href="#" role="button">Add to Cart</a>
                            <hr>
                        </div>
                </div>
            <?php } ?>
        </div>
            
            <!-- Pagination -->
            <div align="center">
                <ul class="pagination pagination-lg" id="page-list">
                    <?php 
                    $base_url = $_SERVER['PHP_SELF']."?brand=$brand&";
                    echo $products->create_links($base_url, $total_rows, $page, $per_page);
                    ?>
                </ul>
            </div>
        
    </div>
    
    <footer>
        <div class="container">
            
        </div>

    </footer>
    <script src="public/vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="public/vendor/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
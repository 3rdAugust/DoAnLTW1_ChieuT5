<?php
    require "db.php";
    class products extends db{
        
        // truy van tat ca san pham
        public function allProducts($page, $per_page)
        {
            $first_link = ($page - 1) * $per_page;
            $sql = "SELECT * FROM products ORDER BY price DESC LIMIT $first_link, $per_page";
            $result = self:: $conn->query($sql);
            return self:: getData($result);
        }
        // dem so luong tat ca san pham
        public function countAll(){
            $sql = "SELECT * FROM products";
            $result = self::$conn->query($sql);
            return $result->num_rows;
        }

        // truy van tat ca san pham theo thuong hieu
        public function readAllProducts($brand, $page, $per_page)
        {
            $first_link = ($page - 1) * $per_page;
            $sql = "SELECT * FROM products WHERE products.brand = '$brand' ORDER BY price DESC LIMIT $first_link, $per_page";
            $result = self:: $conn->query($sql);
            return self:: getData($result);
        }
        // dem so luong san pham theo thuong hieu
        public function countAllProducts($brand){
            $sql = "SELECT * FROM products  WHERE products.brand = '$brand'";
            $result = self::$conn->query($sql);
            return $result->num_rows;
        }

        // tao danh sach phan trang
        public function create_links ($base_url, $total_rows, $page, $per_page)
        {
            $total_links = ceil($total_rows/$per_page);
            $link ="";
            for($j=1; $j <= $total_links ; $j++)
            {
                $link = $link."<li class=".'page'."><a href='".$base_url."page=$j'> $j </a></li>";
            }
            return $link;
        }

        
    }